﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ReservService
{
    [Route("api/reservations")]
    public class ReserveController : ControllerBase
    {
        private readonly IReserveService _service;
        public ReserveController(IReserveService service) => _service = service;

        [HttpGet("{id}/rooms")]
        public async Task<List<Reserve>> GetByRooms(Guid id)
        {
            CancellationToken cts = new CancellationToken();
            return await _service.GetReservesByRoomId(id, cts);
        }

        [HttpGet("{id}/byHotel")]
        public async Task<List<Reserve>> GetByHotel(Guid id)
        {
            CancellationToken cts = new CancellationToken();
            return await _service.GetReservesByHotelId(id, cts);
        }

        [HttpGet("{id}/user")]
        public async Task<List<Reserve>> Get(Guid id)
        {
            CancellationToken cts = new CancellationToken();
            return await _service.GetReservesByUserId(id, cts);
        }

        [HttpPost]
        public async void Post(Reserve reserve)
        {
            CancellationToken ct = new CancellationToken();
            await _service.RegisterReserve(reserve, ct);
        }

        [HttpPut("/update")]
        public async void PutUpdate(Reserve reserve)
        {
            CancellationToken ct = new CancellationToken();
            await _service.UpdateReserve(reserve, ct);
        }

        [HttpPut("{id}/cancel")]
        public async void PutCancel(Guid id)
        {
            CancellationToken ct = new CancellationToken();
            await _service.CancelReserve(id, ct);
        }
    }
}
