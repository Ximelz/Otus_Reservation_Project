﻿namespace ReservService
{
    public class ReserveDto
    {
        public Guid userId;
        public Guid roomId;
        public Guid hotelId;
        public DateTime checkIn;
        public DateTime checkOut;
        public int guestCount;
    }
}
